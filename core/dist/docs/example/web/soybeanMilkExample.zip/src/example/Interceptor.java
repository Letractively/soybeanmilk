package example;

import java.lang.reflect.Type;

import org.soybeanMilk.core.ConvertExecuteException;
import org.soybeanMilk.core.Execution;
import org.soybeanMilk.core.InvocationExecuteException;
import org.soybeanMilk.core.bean.ConvertException;
import org.soybeanMilk.web.bean.ParamConvertException;

public class Interceptor
{
	public void handleBefore(Execution execution)
	{
		System.out.println("before handler executed"+" (\""+execution.getExecutable().getName()+"\")");
	}
	
	public void handleAfter(Execution execution)
	{
		System.out.println("after handler executed"+" (\""+execution.getExecutable().getName()+"\")");
	}
	
	public String handleException(Execution execution)
	{
		System.out.println("exception handler executed"+" (\""+execution.getExecutable().getName()+"\")");
		
		String msg=null;
		
		Throwable cause=execution.getExecuteException();
		
		if(cause instanceof InvocationExecuteException)
		{
			InvocationExecuteException ite=(InvocationExecuteException)cause;
			msg=ite.getCause().getMessage();
		}
		else if(cause instanceof ConvertExecuteException)
		{
			ConvertException cvte=((ConvertExecuteException)cause).getCause();
			
			if(cvte instanceof ParamConvertException)
			{
				ParamConvertException pce=(ParamConvertException)cvte;
				
				msg="The parameter [name: \""+pce.getParamName()+"\", value: \""+pce.getSourceObject()+"\"]";
				
				Type targetType=pce.getTargetType();
				if(Integer.class.equals(targetType)
						|| int.class.equals(targetType))
					msg+=" is not valid integer.";
				else
					msg+=" is invalid";
			}
			else
				msg+=cvte.getMessage();
		}
		else
			msg="unknown error";
		
		return msg+" (\""+execution.getExecutable().getName()+"\")";
	}
}
