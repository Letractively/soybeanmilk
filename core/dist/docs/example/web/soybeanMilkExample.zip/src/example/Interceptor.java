package example;

import org.soybeanMilk.core.ConvertExecuteException;
import org.soybeanMilk.core.Execution;
import org.soybeanMilk.core.InvocationExecuteException;

public class Interceptor
{
	public void handleBefore(Execution execution)
	{
		System.out.println("before handler executed"+" (\""+execution.getExecutable().getName()+"\")");
	}
	
	public void handleAfter(Execution execution)
	{
		System.out.println("after handler executed"+" (\""+execution.getExecutable().getName()+"\")");
	}
	
	public String handleException(Execution execution)
	{
		System.out.println("exception handler executed"+" (\""+execution.getExecutable().getName()+"\")");
		
		String msg=null;
		
		Throwable cause=execution.getExecuteException();
		
		if(cause instanceof InvocationExecuteException)
		{
			InvocationExecuteException ite=(InvocationExecuteException)cause;
			msg=ite.getCause().getMessage();
		}
		else if(cause instanceof ConvertExecuteException)
		{
			msg="����Ƿ�";
		}
		else
			msg="unknown error";
		
		return msg+" (\""+execution.getExecutable().getName()+"\")";
	}
}
