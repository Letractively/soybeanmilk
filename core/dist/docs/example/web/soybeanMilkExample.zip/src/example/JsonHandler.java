package example;

import java.io.IOException;
import java.util.Map;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletResponse;

import org.soybeanMilk.web.WebConstants;
import org.soybeanMilk.web.exe.WebAction;
import org.soybeanMilk.web.exe.th.AbstractTargetHandler;
import org.soybeanMilk.web.os.WebObjectSource;

import example.json.SomeManager.SomeObj;

public class JsonHandler extends AbstractTargetHandler
{
	@Override
	public void handleTarget(WebAction webAction, WebObjectSource webObjectSource)
			throws ServletException, IOException
	{
		HttpServletResponse response=webObjectSource.getResponse();
		
		Map<String, Object> requestObjs=getResultInScope(webAction, webObjectSource, WebConstants.WebObjectSourceScope.REQUEST);
		
		response.setContentType("text/html;charset=UTF-8");
		
		response.getWriter().print(mapToJson(requestObjs));
	}
	
	protected String mapToJson(Map<String, ?> map)
	{
		StringBuffer json=new StringBuffer();
		json.append('{');
		
		Set<String> keySet=map.keySet();
		
		int i=0;
		for(String key : keySet)
		{
			json.append(" "+key+": ");
			Object o=map.get(key);
			
			if(o instanceof SomeObj)
			{
				json.append("{");
				SomeObj so=(SomeObj)o;
				
				json.append("name: \""+so.getName()+"\", value: \""+so.getValue()+"\"");
				
				json.append("}");
			}
			else if(o instanceof String)
			{
				json.append("\""+o+"\"");
			}
			else
			{
				json.append("...");
			}
			
			if(i < keySet.size()-1)
				json.append(", ");
			
			i++;
		}
		
		json.append(" }");
		
		return json.toString();
	}
}
