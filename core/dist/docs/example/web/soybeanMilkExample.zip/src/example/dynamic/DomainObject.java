package example.dynamic;

public class DomainObject
{
	private Integer id;
	private String name;
	
	private boolean saved=false;
	
	public DomainObject save()
	{
		this.saved=true;
		
		return this;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String toString()
	{
		return "DomainObject [id=" + id + ", name=" + name + ", saved=" + saved
				+ "]";
	}
}
