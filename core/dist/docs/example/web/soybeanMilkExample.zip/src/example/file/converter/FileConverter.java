package example.file.converter;

import java.io.File;
import java.lang.reflect.Type;

import javax.servlet.http.HttpServletRequest;

import org.soybeanMilk.core.bean.ConvertException;
import org.soybeanMilk.core.bean.Converter;

public class FileConverter implements Converter
{
	//@Override
	@SuppressWarnings("unchecked")
	public <T> T convert(Object arg0, Type arg1) throws ConvertException
	{
		HttpServletRequest request=(HttpServletRequest)arg0;
		
		request.getContentLength();
		
		/**
		 * ... ʹ���ļ��ϴ������request��ȡ���ļ�
		 */
		
		return (T)tmpFile;
	}
	
	private static File tmpFile=null;
	static
	{
		try
		{
			tmpFile=File.createTempFile("upload_file", ".txt");
		}
		catch(Exception e){}
	}
}
