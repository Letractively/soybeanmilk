package example.file.converter;

import java.io.File;
import java.lang.reflect.Type;

import javax.servlet.http.HttpServletRequest;

import org.soybeanMilk.core.bean.Converter;

public class FileConverter implements Converter
{
	//@Override
	public Object convert(Object arg0, Type arg1)
	{
		HttpServletRequest request=(HttpServletRequest)arg0;
		
		/**
		 * ... ʹ���ļ��ϴ������request��ȡ���ļ�
		 */
		
		return tmpFile;
	}
	
	private static File tmpFile=null;
	static
	{
		try
		{
			tmpFile=File.createTempFile("upload_file", ".txt");
		}
		catch(Exception e){}
	}
}
