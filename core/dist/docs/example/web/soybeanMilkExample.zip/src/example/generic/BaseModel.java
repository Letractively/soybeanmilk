package example.generic;

public class BaseModel{}
