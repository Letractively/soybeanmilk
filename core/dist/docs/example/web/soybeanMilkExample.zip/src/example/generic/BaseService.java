package example.generic;

import java.util.List;

public interface BaseService<T extends BaseModel>
{
	String save(T t);
	
	String saveAll(List<T> ts);
	
	String delete(T... t);
}
