package example.generic;

import java.util.List;

public class BaseServiceImpl<T> implements BaseService<T>
{
	public String save(T t)
	{
		return "BaseServiceImpl.save(T t) is :"+t.toString();
	}

	public String saveAll(List<T> t)
	{
		StringBuilder sb=new StringBuilder();
		
		sb.append("BaseServiceImpl.save(List<T> t) is :");
		for(T tmp : t)
		{
			sb.append(tmp.toString());
			sb.append("; ");
		}
		
		return sb.toString();
	}

	public String delete(T... t)
	{
		StringBuilder sb=new StringBuilder();
		
		sb.append("BaseServiceImpl.delete(T... t) is :");
		for(T tmp : t)
		{
			sb.append(tmp.toString());
			sb.append("; ");
		}
		
		return sb.toString();
	}
}
