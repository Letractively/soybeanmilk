package example.generic;

import java.util.List;

public class BaseServiceImpl<T extends BaseModel> implements BaseService<T>
{
	public String save(T t)
	{
		return "BaseServiceImpl.save(T t) :<br>"+t.toString();
	}

	public String saveAll(List<T> t)
	{
		StringBuilder sb=new StringBuilder();
		
		sb.append("BaseServiceImpl.save(List&lt;T&gt; t) :<br>");
		for(T tmp : t)
		{
			sb.append(tmp.toString());
			sb.append(";<br>");
		}
		
		return sb.toString();
	}

	public String delete(T... t)
	{
		StringBuilder sb=new StringBuilder();
		
		sb.append("BaseServiceImpl.delete(T... t) :<br>");
		for(T tmp : t)
		{
			sb.append(tmp.toString());
			sb.append(";<br>");
		}
		
		return sb.toString();
	}
}
