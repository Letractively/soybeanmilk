package example.generic;

public class Order
{
	private Integer number;
	private String user;
	
	public Integer getNumber() {
		return number;
	}
	public void setNumber(Integer number) {
		this.number = number;
	}
	public String getUser() {
		return user;
	}
	public void setUser(String user) {
		this.user = user;
	}
	
	@Override
	public String toString()
	{
		return "example.generic.Order [number=" + number + ", user=" + user + "]";
	}
}
