package example.generic;

public interface OrderService extends BaseService<Order>{}
