package example.generic;

public class OrderServiceImpl extends BaseServiceImpl<Order> implements OrderService
{
	@Override
	public String delete(Order... t)
	{
		StringBuilder sb=new StringBuilder();
		
		sb.append("OrderServiceImpl.delete(Order... t) is :");
		for(Order tmp : t)
		{
			sb.append(tmp.toString());
			sb.append("; ");
		}
		
		return sb.toString();
	}
}
