package example.generic;

public class OrderServiceImpl extends BaseServiceImpl<Order> implements OrderService
{
	@Override
	public String delete(Order... t)
	{
		StringBuilder sb=new StringBuilder();
		
		sb.append("OrderServiceImpl.delete(Order... t) :<br>");
		for(Order tmp : t)
		{
			sb.append(tmp.toString());
			sb.append(";<br>");
		}
		
		return sb.toString();
	}
}
