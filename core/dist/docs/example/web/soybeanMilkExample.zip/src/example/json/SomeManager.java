package example.json;

public class SomeManager
{
	public SomeObj getSomeObj(String name)
	{
		SomeObj someObj=new SomeObj();
		someObj.setName(name);
		someObj.setValue("someValue");
		
		return someObj;
	}
	
	public String anotherObj()
	{
		return "stringObject";
	}
	
	public static class SomeObj
	{
		private String name;
		private String value;
		
		public String getName()
		{
			return name;
		}
		public void setName(String name)
		{
			this.name = name;
		}
		public String getValue()
		{
			return value;
		}
		public void setValue(String value)
		{
			this.value = value;
		}
	}
}
