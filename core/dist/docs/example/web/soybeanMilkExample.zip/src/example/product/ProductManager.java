package example.product;

import java.util.ArrayList;
import java.util.List;

public class ProductManager
{
	private static List<Product> productDs=new ArrayList<Product>();
	
	public void addProduct(List<Product> products)
	{
		if(products == null)
			return;
		
		for(Product p : products)
			productDs.add(p);
	}
	
	public void delete(Integer[] numbers)
	{
		if(numbers == null)
			return;
		
		for(Integer num : numbers)
		{
			for(int i=0;i<productDs.size();i++)
			{
				Product p = productDs.get(i);
				
				if(p.getNumber().equals(num))
					productDs.remove(i);
			}
		}
	}
	
	public List<Product> listAll()
	{
		return productDs;
	}
}
