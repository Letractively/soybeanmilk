package example.resolver;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import example.resolver.vo.Friend;

public class FriendManager
{
	private static Map<String, List<Friend>> userFriends=new HashMap<String, List<Friend>>();
	
	/**
	 * ���Ӻ���
	 * @param userId
	 * @param friend
	 * @return
	 */
	public boolean addFriend(String userId, Friend friend)
	{
		if(userId == null)
			throw new IllegalArgumentException("�û�ID ����Ϊ��");
		if(friend == null)
			throw new IllegalArgumentException("Ҫ���ӵĺ��� ����Ϊ��");
		
		List<Friend> friends=userFriends.get(userId);
		if(friends == null)
		{
			friends=new ArrayList<Friend>();
			userFriends.put(userId, friends);
		}
		
		friends.add(friend);
		
		return true;
	}
	
	/**
	 * �����û��ĺ����б�
	 * @param userId
	 * @return
	 */
	public List<Friend> findAllFriends(String userId)
	{
		return userId == null ? null : userFriends.get(userId);
	}
}
