package example.spring;

public class SpringBeanResolver
{
	public String resolve(String argument)
	{
		return "I am a spring bean resolver for resolving : "+argument;
	}
}
