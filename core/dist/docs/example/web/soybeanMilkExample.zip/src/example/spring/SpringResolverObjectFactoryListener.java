package example.spring;

import java.io.Serializable;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import org.soybeanMilk.core.exe.support.ResolverObjectFactory;

import example.spring.org.springframework.web.context.WebApplicationContext;
import example.spring.org.springframework.web.context.support.WebApplicationContextUtils;

public class SpringResolverObjectFactoryListener implements ServletContextListener
{
	public static final String SPRING_RESOLVER_FACTORY_KEY="springResolverObjectFactory";
	
	public void contextDestroyed(ServletContextEvent event)
	{
		event.getServletContext().removeAttribute(SPRING_RESOLVER_FACTORY_KEY);
	}
	
	public void contextInitialized(ServletContextEvent event)
	{
		ResolverObjectFactory rof=null;
		
		ServletContext servletContext=event.getServletContext();
		final WebApplicationContext springContext=WebApplicationContextUtils.getWebApplicationContext(servletContext);
		
		if(springContext != null)
		{
			rof=new ResolverObjectFactory()
			{
				public Object getResolverObject(Serializable resolverObjectId)
				{
					String name=(resolverObjectId instanceof String ? (String)resolverObjectId : resolverObjectId.toString());
					
					if(springContext.containsBean(name))
						return springContext.getBeans(name);
					else
						return null;
				}
				
				public void addResolverObject(Serializable resolverObjectId, Object resolverObject){}
			};
		}
		
		servletContext.setAttribute(SPRING_RESOLVER_FACTORY_KEY, rof);
	}
}
