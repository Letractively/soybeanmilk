package example.spring.org.springframework.web.context;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

public class ContextLoaderListener implements ServletContextListener
{
	public void contextDestroyed(ServletContextEvent event)
	{
		event.getServletContext().removeAttribute(WebApplicationContext.WEB_APPLICATION_CONTEXT_ATTRIBUTE);
	}
	
	public void contextInitialized(ServletContextEvent event)
	{
		event.getServletContext().setAttribute(WebApplicationContext.WEB_APPLICATION_CONTEXT_ATTRIBUTE, new WebApplicationContext());
	}
}
