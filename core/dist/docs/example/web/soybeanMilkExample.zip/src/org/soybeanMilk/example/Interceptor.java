/**
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 * 	http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License. 
 */

package org.soybeanMilk.example;

import java.lang.reflect.Type;

import org.soybeanMilk.core.Execution;
import org.soybeanMilk.core.exe.ArgPrepareExecuteException;
import org.soybeanMilk.core.exe.InvocationExecuteException;
import org.soybeanMilk.web.os.ParamIllegalException;

/**
 * SoybeanMilkʾ��
 * @author earthangry@gmail.com
 * @date 2012-6-2
 */
public class Interceptor
{
	public void handleBefore(Execution execution)
	{
		System.out.println("before handler executed"+" (\""+execution.getExecutable().getName()+"\")");
	}
	
	public void handleAfter(Execution execution)
	{
		System.out.println("after handler executed"+" (\""+execution.getExecutable().getName()+"\")");
	}
	
	public String handleException(Execution execution)
	{
		System.out.println("exception handler executed"+" (\""+execution.getExecutable().getName()+"\")");
		
		String msg=null;
		
		Throwable cause=execution.getExecuteException();
		
		if(cause instanceof InvocationExecuteException)
		{
			InvocationExecuteException ite=(InvocationExecuteException)cause;
			msg=ite.getCause().getMessage();
		}
		else if(cause instanceof ArgPrepareExecuteException)
		{
			ArgPrepareExecuteException apee=(ArgPrepareExecuteException)cause;
			Throwable th=apee.getCause();
			
			if(th instanceof ParamIllegalException)
			{
				ParamIllegalException pie=(ParamIllegalException)th;
				
				msg="The parameter [name: \""+pie.getParamName()+"\", value: \""+pie.getParamValue()+"\"]";
				
				Type targetType=pie.getTargetType();
				if(Integer.class.equals(targetType)
						|| int.class.equals(targetType))
					msg+=" is not valid integer.";
				else
					msg+=" is invalid";
			}
			else
				msg+=apee.getMessage();
		}
		else
			msg="unknown error";
		
		return msg+" (\""+execution.getExecutable().getName()+"\")";
	}
}
