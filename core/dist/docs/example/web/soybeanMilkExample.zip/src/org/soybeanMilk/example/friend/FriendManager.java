/**
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 * 	http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License. 
 */

package org.soybeanMilk.example.friend;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * SoybeanMilkʾ��
 * @author earthangry@gmail.com
 * @date 2012-6-2
 */
public class FriendManager
{
	private static Map<String, List<Friend>> userFriends=new HashMap<String, List<Friend>>();
	
	/**
	 * ���Ӻ���
	 * @param userId
	 * @param friend
	 * @return
	 */
	public boolean addFriend(String userId, Friend friend)
	{
		if(userId == null)
			throw new IllegalArgumentException("�û�ID ����Ϊ��");
		if(friend == null)
			throw new IllegalArgumentException("Ҫ���ӵĺ��� ����Ϊ��");
		
		List<Friend> friends=userFriends.get(userId);
		if(friends == null)
		{
			friends=new ArrayList<Friend>();
			userFriends.put(userId, friends);
		}
		
		friends.add(friend);
		
		return true;
	}
	
	/**
	 * �����û��ĺ����б�
	 * @param userId
	 * @return
	 */
	public List<Friend> findAllFriends(String userId)
	{
		return userId == null ? null : userFriends.get(userId);
	}
}
