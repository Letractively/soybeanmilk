package org.soybeanMilk.example.spring.org.springframework.web.context;

import java.util.HashMap;
import java.util.Map;

import org.soybeanMilk.example.spring.SpringBeanResolver;


public class WebApplicationContext
{
	public static final String WEB_APPLICATION_CONTEXT_ATTRIBUTE="webApplicationContext";
	
	private Map<String, Object> beans;
	
	public WebApplicationContext()
	{
		this.beans=new HashMap<String, Object>();
		
		this.beans.put("springBeanResolver", new SpringBeanResolver());
	}
	
	public Object getBeans(String name)
	{
		return this.beans.get(name);
	}
	
	public boolean containsBean(String name)
	{
		return this.beans.get(name) != null;
	}
}
