package org.soybeanMilk.example.spring.org.springframework.web.context.support;

import javax.servlet.ServletContext;

import org.soybeanMilk.example.spring.org.springframework.web.context.WebApplicationContext;


public class WebApplicationContextUtils
{
	public static WebApplicationContext getWebApplicationContext(ServletContext sc)
	{
		return (WebApplicationContext)sc.getAttribute(WebApplicationContext.WEB_APPLICATION_CONTEXT_ATTRIBUTE);
	}
}
