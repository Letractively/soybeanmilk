
* 此框架需要JDK1.5+支持。

* 你需要将“soybeanMilk-[version].jar”和必须的依赖库“lib/required/*.jar”拷贝到你的类路径中。

* “docs”文件夹下有详细的使用指南和说明文档，“docs/example/web/soybeanMilkExample.zip”是一个eclipse-jee示例工程，导入后设置应用服务器（比如tomcat）后即可运行。