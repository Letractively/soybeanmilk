
* 此框架需要JDK1.5+支持。

* 使用时你需要将“soybeanMilk-[version].jar”和必须的依赖库“lib/required/*.jar”拷贝到你的类路径中。

* “docs”文件夹下有详细的使用指南和说明文档，其中：

	“docs/example/core/”是一些示例程序和源代码，点击“run.bat”即可运行此示例程序
	“docs/example/web/soybeanMilkExample.zip”是一个eclipse-jee示例工程，导入后设置应用服务器（比如tomcat6）后即可运行