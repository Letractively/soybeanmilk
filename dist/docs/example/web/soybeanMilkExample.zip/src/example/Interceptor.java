package example;

import java.lang.reflect.InvocationTargetException;

import org.soybeanMilk.core.Execution;

public class Interceptor
{
	public void handleBefore()
	{
		System.out.println("before handler executed");
	}
	
	public void handleAfter()
	{
		System.out.println("after handler executed");
	}
	
	public String handleException(Execution execution)
	{
		System.out.println("exception handler executed");
		
		String msg=null;
		
		Throwable cause=execution.getExecuteException().getCause();
		
		if(cause instanceof InvocationTargetException)
		{
			InvocationTargetException ite=(InvocationTargetException)cause;
			msg=ite.getCause().getMessage();
		}
		else
			msg="unknown error";
		
		return msg+" (\""+execution.getExecutable().getName()+"\")";
	}
}
