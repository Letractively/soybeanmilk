package example;

import java.lang.reflect.InvocationTargetException;

import org.soybeanMilk.core.ExecuteException;

public class Interceptor
{
	public void handleBefore()
	{
		System.out.println("before handler executed");
	}
	
	public void handleAfter()
	{
		System.out.println("after handler executed");
	}
	
	public String handleException(ExecuteException exception)
	{
		System.out.println("exception handler executed");
		
		String msg=null;
		
		Throwable cause=exception.getCause();
		
		if(cause instanceof InvocationTargetException)
		{
			InvocationTargetException ite=(InvocationTargetException)cause;
			msg=ite.getCause().getMessage();
		}
		else
			msg="unknown error";
		
		return msg;
	}
}
