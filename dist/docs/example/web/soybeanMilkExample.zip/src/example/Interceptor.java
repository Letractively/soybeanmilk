package example;

import java.lang.reflect.InvocationTargetException;

import org.soybeanMilk.core.Execution;

public class Interceptor
{
	public void handleBefore(Execution execution)
	{
		System.out.println("before handler executed"+" (\""+execution.getExecutable().getName()+"\")");
	}
	
	public void handleAfter(Execution execution)
	{
		System.out.println("after handler executed"+" (\""+execution.getExecutable().getName()+"\")");
	}
	
	public String handleException(Execution execution)
	{
		System.out.println("exception handler executed"+" (\""+execution.getExecutable().getName()+"\")");
		
		String msg=null;
		
		Throwable cause=execution.getExecuteException().getCause();
		
		if(cause instanceof InvocationTargetException)
		{
			InvocationTargetException ite=(InvocationTargetException)cause;
			msg=ite.getCause().getMessage();
		}
		else
			msg="unknown error";
		
		return msg+" (\""+execution.getExecutable().getName()+"\")";
	}
}
