package example.converter;

import java.io.File;

import javax.servlet.http.HttpServletRequest;

import org.soybeanMilk.core.bean.Converter;

public class FileConverter implements Converter
{
	@Override
	public Object convert(Object arg0, Class<?> arg1)
	{
		HttpServletRequest request=(HttpServletRequest)arg0;
		
		/**
		 * TODO ʹ���ļ��ϴ������request��ȡ���ļ�
		 */
		
		return tmpFile;
	}
	
	private static File tmpFile=null;
	static
	{
		try
		{
			tmpFile=File.createTempFile("upload_file", ".txt");
		}
		catch(Exception e){}
	}
}
