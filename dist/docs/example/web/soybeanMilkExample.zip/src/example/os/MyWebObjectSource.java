package example.os;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.soybeanMilk.core.bean.GenericConverter;
import org.soybeanMilk.web.os.WebObjectSource;

public class MyWebObjectSource extends WebObjectSource
{
	public MyWebObjectSource(HttpServletRequest request,
			HttpServletResponse response, ServletContext application,
			GenericConverter genericConverter)
	{
		super(request, response, application, genericConverter);
	}

	public MyWebObjectSource(HttpServletRequest request,
			HttpServletResponse response, ServletContext application)
	{
		super(request, response, application);
	}

}
