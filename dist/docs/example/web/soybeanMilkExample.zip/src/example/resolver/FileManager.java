package example.resolver;

import java.io.File;

public class FileManager
{
	public String saveFile(File f)
	{
		System.out.println("�鵵�ļ�'"+f.getName()+"'");
		
		return f.getName();
	}
}
