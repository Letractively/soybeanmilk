package example.resolver;

public class Hello
{
	private String me;
	
	public Hello()
	{
		this.me="soybeanMilk";
	}
	
	public String hello(String to, int repeat)
	{
		if(repeat<=0)
			throw new IllegalArgumentException("����[repeat]��ֵ�������0");
		
		String re="";
		
		for(int i=0;i<repeat;i++)
		{
			re+="Hello "+to+", I am "+this.me+"! <br/>";
		}
		
		return re;
	}
	
	public static void printObject(Object object)
	{
		System.out.println(object);
	}
}
