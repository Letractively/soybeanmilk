package example;

import java.lang.reflect.InvocationTargetException;

import org.soybeanMilk.core.ExecuteException;

public class ExceptionHandler
{
	public String handleException(ExecuteException exception)
	{
		String msg=null;
		
		Throwable cause=exception.getCause();
		
		if(cause instanceof InvocationTargetException)
		{
			InvocationTargetException ite=(InvocationTargetException)cause;
			msg=ite.getCause().getMessage();
		}
		else
			msg="unknown error";
		
		return msg;
	}
}
